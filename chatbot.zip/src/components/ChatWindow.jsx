import React, { useEffect, useRef } from "react";
import Message from "./Message";

const ChatWindow = ({ messages, loading }) => {
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  return (
    <div
      className="chat-window"
      style={{ overflowY: "auto", maxHeight: "400px", padding: "10px" }}
    >
      {messages.map((msg, idx) => (
        <Message key={idx} sender={msg.sender} text={msg.text} />
      ))}

      <div ref={bottomRef} />
    </div>
  );
};

export default ChatWindow;
