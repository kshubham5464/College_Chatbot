import React, { useState, useEffect } from 'react';
import ChatWindow from './ChatWindow';
import InputBox from './InputBox';
import { getBotResponse } from '../services/chatbotServices';
import logo from '../assets/logo.jpg';


const Chatbot = () => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const initialMessage = { sender: 'bot', text: 'Hello, how can I assist you?' };
    setMessages([initialMessage]);
  }, []);

  const handleSendMessage = async (userInput) => {
    if (userInput.trim() === '') return;

    setLoading(true);
    const userMessage = { sender: 'user', text: userInput };
    setMessages([...messages, userMessage]);

    try {
      const botResponse = await getBotResponse(userInput);
      const botMessage = { sender: 'bot', text: botResponse };
      setMessages([...messages, userMessage, botMessage]);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="chatbot">
      <div className="chatbot-header">
        <img src={logo} alt="Chatbot Logo" className="chatbot-logo" />
        {/* <h2>Chatbot</h2> */}
      </div>
      <ChatWindow messages={messages} loading={loading} />
      <InputBox onSend={handleSendMessage} disabled={loading} />
    </div>
  );
};

export default Chatbot;